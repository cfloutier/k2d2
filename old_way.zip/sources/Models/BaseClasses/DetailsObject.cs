﻿namespace K2D2.sources.Models.BaseClasses
{
    public class DetailsObject
    {
        
    }
}