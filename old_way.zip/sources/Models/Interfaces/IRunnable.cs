﻿namespace K2D2.sources.Models
{
    public interface IRunnable
    {
        // Contains the Run() function
        void Run();

    }
}