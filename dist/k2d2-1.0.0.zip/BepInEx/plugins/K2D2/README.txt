# K.2.D.2

The Kerbal Space Programm astromech

A set of tools to Help Space Navigation.

availables (progress mean coding progress before final version):

- Execute the next maneuvre node for the moment and added auto circle to Ap and Pe. (progress 4/5)

- Automatic landing (progress 2/5)

- Lift : Automatic Ascent Profile (progress 2/5)

- Drone : New Flying mode, Very Costly in dv (use Infinite Fuel) but really fun to use (progress 4 /5)

- Attitude : point the vessel in the wanted direction, (plane autopilot)  (progress 3 /5)

- Warp  : warp to SOI changes  (progress 1 /5)

- Dock : Auto dock (progress 2/5)

The UI can be opened using `Alt-O` or using AppBar.

----------------

# Installation

Open the game folder by right-clicking on the game in your Steam library, selecting "Manage," and then clicking "Browse local files."

Install the Space Warp + BepinEx plugin. 
https://spacedock.info/mod/3277/Space%20Warp%20+%20BepInEx

Download K2-D2, open the zip file, and drag the included `BepInEx` folder into the game folder. (merge folders when asked)


# Thanks to

Thanks first for downloading.

* Thanks to [Mole](https://github.com/Mole1803) for the hard work on Circularize ! 

* Thanks to [schlosrat (he/him)](https://forum.kerbalspaceprogram.com/index.php?/profile/141963-schlosrat/) for testing and many help on code. Especially for the node creation.

* Thanks to Opus (#Opus#7354) for the name of the Mod ! 

* Big Thanks to [cheese3660](https://github.com/cheese3660)
1. for [SpaceWarp](https://github.com/Halbann). the base of all KSP2 MODs we can make for now on
2. and for [AutoBurn](https://github.com/cheese3660/AutoBurn) Very helpful code about how to start thrusts and how to get maneuvre node.

* my first steps was based on [LazyOrbit](https://github.com/Halbann/LazyOrbit)
Thanks for this excellent first step ! a light code, simple and very well written.

# Licenses

* K2-D2 is distributed under the CC BY-SA 4.0 license. Read about the license here before redistributing:
https://creativecommons.org/licenses/by-sa/4.0/
* use the Caravan Font :  license: Freeware, Non-Commercial - https://www.fontspace.com/acorn-caravan-font-f40558
